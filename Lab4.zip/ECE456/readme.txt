run with python 3
It follows the specifications given in the lab instructions, for example:
.\sender.py dataFile.txt 68.87.85.98    192.168.1.102    53    59887    output

The lab1 folder holds the encrypt and decrypt classes, while the lab2 folder has the receiver and sender files